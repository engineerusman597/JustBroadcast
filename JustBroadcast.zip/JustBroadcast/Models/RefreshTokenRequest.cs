namespace JustBroadcast.Models
{
    public class RefreshTokenRequest
    {
        public string? RefreshToken { get; set; }
    }
}
