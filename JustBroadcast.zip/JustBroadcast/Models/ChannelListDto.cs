namespace JustBroadcast.Models
{
    public class ChannelListDto
    {
        public required string Id { get; set; }
        public string? Name { get; set; }
    }
}
