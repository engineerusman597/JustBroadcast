namespace JustBroadcast.Models
{
    public class ChannelListCountDto
    {
        public int? TotalChannels { get; set; }
        public int? Connected { get; set; }
        public int? Disconnected { get; set; }
    }
}
