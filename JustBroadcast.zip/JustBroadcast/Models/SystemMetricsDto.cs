namespace JustBroadcast.Models
{
    public class SystemMetricsDto
    {
        public int cpuPercent { get; set; }
        public int gpuPercent { get; set; }
        public int ramPercent { get; set; }
    }
}
