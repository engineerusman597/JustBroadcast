namespace JustBroadcast.Models
{
    public enum UserRole
    {
        Supervisor = 0,
        Administrator = 1,
        Operator = 2,
        Viewer = 3
    }
}
