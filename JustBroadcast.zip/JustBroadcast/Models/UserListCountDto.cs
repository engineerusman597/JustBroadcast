namespace JustBroadcast.Models
{
    public class UserListCountDto
    {
        public int? TotalUsers { get; set; }
    }
}
